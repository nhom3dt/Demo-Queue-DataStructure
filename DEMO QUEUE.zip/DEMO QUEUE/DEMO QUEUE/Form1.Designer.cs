﻿namespace DEMO_QUEUE
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txtQueue = new System.Windows.Forms.TextBox();
            this.btnEnQueue = new System.Windows.Forms.Button();
            this.txtData = new System.Windows.Forms.TextBox();
            this.btnDeQueue = new System.Windows.Forms.Button();
            this.btnPeek = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnCount = new System.Windows.Forms.Button();
            this.lblDeQueue = new System.Windows.Forms.Label();
            this.lblPeek = new System.Windows.Forms.Label();
            this.lblCount = new System.Windows.Forms.Label();
            this.btnContain = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnUngdung = new System.Windows.Forms.Button();
            this.btnInfo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtQueue
            // 
            this.txtQueue.Location = new System.Drawing.Point(480, 185);
            this.txtQueue.Multiline = true;
            this.txtQueue.Name = "txtQueue";
            this.txtQueue.ReadOnly = true;
            this.txtQueue.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtQueue.Size = new System.Drawing.Size(113, 209);
            this.txtQueue.TabIndex = 0;
            this.txtQueue.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtQueue_MouseClick);
            // 
            // btnEnQueue
            // 
            this.btnEnQueue.Location = new System.Drawing.Point(250, 310);
            this.btnEnQueue.Name = "btnEnQueue";
            this.btnEnQueue.Size = new System.Drawing.Size(89, 29);
            this.btnEnQueue.TabIndex = 1;
            this.btnEnQueue.Text = "EnQueue";
            this.btnEnQueue.UseVisualStyleBackColor = true;
            this.btnEnQueue.Click += new System.EventHandler(this.btnEnQueue_Click);
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(371, 310);
            this.txtData.Multiline = true;
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(100, 29);
            this.txtData.TabIndex = 2;
            // 
            // btnDeQueue
            // 
            this.btnDeQueue.Location = new System.Drawing.Point(624, 242);
            this.btnDeQueue.Name = "btnDeQueue";
            this.btnDeQueue.Size = new System.Drawing.Size(88, 32);
            this.btnDeQueue.TabIndex = 3;
            this.btnDeQueue.Text = "DeQueue";
            this.btnDeQueue.UseVisualStyleBackColor = true;
            this.btnDeQueue.Click += new System.EventHandler(this.btnDeQueue_Click);
            // 
            // btnPeek
            // 
            this.btnPeek.Location = new System.Drawing.Point(624, 305);
            this.btnPeek.Name = "btnPeek";
            this.btnPeek.Size = new System.Drawing.Size(88, 29);
            this.btnPeek.TabIndex = 4;
            this.btnPeek.Text = "Peek";
            this.btnPeek.UseVisualStyleBackColor = true;
            this.btnPeek.Click += new System.EventHandler(this.btnPeek_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(480, 411);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(113, 27);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnCount
            // 
            this.btnCount.Location = new System.Drawing.Point(624, 356);
            this.btnCount.Name = "btnCount";
            this.btnCount.Size = new System.Drawing.Size(86, 30);
            this.btnCount.TabIndex = 6;
            this.btnCount.Text = "Count";
            this.btnCount.UseVisualStyleBackColor = true;
            this.btnCount.Click += new System.EventHandler(this.btnCount_Click);
            // 
            // lblDeQueue
            // 
            this.lblDeQueue.AutoSize = true;
            this.lblDeQueue.Location = new System.Drawing.Point(736, 250);
            this.lblDeQueue.Name = "lblDeQueue";
            this.lblDeQueue.Size = new System.Drawing.Size(0, 17);
            this.lblDeQueue.TabIndex = 7;
            // 
            // lblPeek
            // 
            this.lblPeek.AutoSize = true;
            this.lblPeek.Location = new System.Drawing.Point(735, 316);
            this.lblPeek.Name = "lblPeek";
            this.lblPeek.Size = new System.Drawing.Size(0, 17);
            this.lblPeek.TabIndex = 8;
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Location = new System.Drawing.Point(735, 377);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(0, 17);
            this.lblCount.TabIndex = 9;
            // 
            // btnContain
            // 
            this.btnContain.Location = new System.Drawing.Point(250, 359);
            this.btnContain.Name = "btnContain";
            this.btnContain.Size = new System.Drawing.Size(89, 27);
            this.btnContain.TabIndex = 10;
            this.btnContain.Text = "Check";
            this.btnContain.UseVisualStyleBackColor = true;
            this.btnContain.Click += new System.EventHandler(this.btnContain_Click);
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Location = new System.Drawing.Point(414, 72);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(239, 66);
            this.panel1.TabIndex = 11;
            // 
            // btnUngdung
            // 
            this.btnUngdung.Location = new System.Drawing.Point(250, 405);
            this.btnUngdung.Name = "btnUngdung";
            this.btnUngdung.Size = new System.Drawing.Size(89, 33);
            this.btnUngdung.TabIndex = 12;
            this.btnUngdung.Text = "Application";
            this.btnUngdung.UseVisualStyleBackColor = true;
            this.btnUngdung.Click += new System.EventHandler(this.btnUngdung_Click);
            // 
            // btnInfo
            // 
            this.btnInfo.Location = new System.Drawing.Point(624, 413);
            this.btnInfo.Name = "btnInfo";
            this.btnInfo.Size = new System.Drawing.Size(96, 30);
            this.btnInfo.TabIndex = 13;
            this.btnInfo.Text = "Information";
            this.btnInfo.UseVisualStyleBackColor = true;
            this.btnInfo.Click += new System.EventHandler(this.btnInfo_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(832, 503);
            this.Controls.Add(this.btnInfo);
            this.Controls.Add(this.btnUngdung);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnContain);
            this.Controls.Add(this.lblCount);
            this.Controls.Add(this.lblPeek);
            this.Controls.Add(this.lblDeQueue);
            this.Controls.Add(this.btnCount);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnPeek);
            this.Controls.Add(this.btnDeQueue);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.btnEnQueue);
            this.Controls.Add(this.txtQueue);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Demo Queue";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtQueue;
        private System.Windows.Forms.Button btnEnQueue;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.Button btnDeQueue;
        private System.Windows.Forms.Button btnPeek;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnCount;
        private System.Windows.Forms.Label lblDeQueue;
        private System.Windows.Forms.Label lblPeek;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Button btnContain;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnUngdung;
        private System.Windows.Forms.Button btnInfo;
    }
}

