﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEMO_QUEUE
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            this.ActiveControl = txtData;
            txtData.Focus();

        }
        Queue<string> queue = new Queue<string>();


        private void btnEnQueue_Click(object sender, EventArgs e)
        {
          
            if(!(txtData.Text==""))
            {
                queue.Enqueue(txtData.Text);
                HienThi(queue);
                txtData.Text = "";
            }
        }
        public void btnDeQueue_Click(object sender, EventArgs e)
        {
            try
            {

                lblDeQueue.Text = queue.Dequeue();
                HienThi(queue);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Không còn dữ liệu để Dequeue, " + ex.Message);
            }
        }

        private void btnPeek_Click(object sender, EventArgs e)
        {
            try
            {
                lblPeek.Text = queue.Peek();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không còn dữ liệu để Peek, " + ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            queue.Clear();
            HienThi(queue);
            lblCount.Text = "";
            lblPeek.Text = "";
            lblDeQueue.Text = "";
        }

        private void btnCount_Click(object sender, EventArgs e)
        {
            string b = Convert.ToString(queue.Count()); // chuyen gia tri tu int sang string
            lblCount.Text = b;
        }
        public void HienThi(IEnumerable st)
        {
            txtQueue.Text = "";
            foreach (IEnumerable m in st)
                txtQueue.Text = m + "\r\n" + txtQueue.Text;
        }

        private void btnContain_Click(object sender, EventArgs e)
        {
            if (!(txtData.Text == "") )
            {
                string cc = txtData.Text;
                MessageBox.Show(Convert.ToString(queue.Contains(cc)), "Does it contain?", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            
        }

        private void txtQueue_MouseClick(object sender, MouseEventArgs e)
        {
            txtData.Focus();
        }

        private void btnUngdung_Click(object sender, EventArgs e)
        {
            new Form2().ShowDialog();
            Close();
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            new Form3().ShowDialog();
        }
    }
}
