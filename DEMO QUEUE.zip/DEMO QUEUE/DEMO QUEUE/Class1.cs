﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace DEMO_QUEUE
{
    class QNode
    {
        public string name;
        public string phone;
        public int key;
        public QNode next;
        public QNode(string name, string phone,int key)
        {
            this.name = name;
            this.phone = phone;
            this.key = key;
            this.next = null;
        }
    }
    class Queue
    {
        QNode front, rear;
        public Queue()
        {
            this.front = this.rear = null;
        }
        public void enqueue(string name, string phone, int key)
        {
            QNode temp = new QNode(name, phone, key);
            if (this.rear == null)
            {
                this.front = this.rear = temp;
                return;
            }
            this.rear.next = temp;
            this.rear = temp;
        }
        public QNode dequeue()
        {
            if (this.front == null)
                return null;
            QNode temp = this.front;
            this.front = this.front.next;
            if (this.front == null)
                this.rear = null;
            return temp;
        }
        public bool IsEmpty()
        {
            if (this.front == null)
                return true;
            return false;
        }
    }
}
