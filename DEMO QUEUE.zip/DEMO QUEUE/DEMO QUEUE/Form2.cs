﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Excel = Microsoft.Office.Interop.Excel;

namespace DEMO_QUEUE
{
    public partial class Form2 : Form
    {
        public string name;
        public string phone;
        public int key = 1;
        Queue Q1 = new Queue();
        Queue Q2 = new Queue();
        Queue Q3 = new Queue();
        public string dateimenow = "";
        public static Excel.Application exApp = new Excel.Application();
        public static Excel.Workbook exBook = exApp.Workbooks.Add(Excel.XlWBATemplate.xlWBATWorksheet);
        public Excel.Worksheet exSheet = (Excel.Worksheet)exBook.Worksheets[1];
        public Form2()
        {
            InitializeComponent();
            nolbl.Text = key.ToString();
            DateTime today = DateTime.Now;
            dateimenow = today.ToString("yyyy-MM-dd")+" "+today.Hour+today.Minute;
            exApp.Visible = false;
            Excel.Range a = (Excel.Range)exSheet.Cells[1, 1];
            Excel.Range b = (Excel.Range)exSheet.Cells[1, 2];
            Excel.Range c = (Excel.Range)exSheet.Cells[1, 3];
            a.Value2 = "Họ và Tên";
            b.Value2 = "Số điện thoại";
            c.Value2 = "Phòng khám";
            a.Columns.AutoFit();
            b.Columns.AutoFit();
            c.Columns.AutoFit();
        }

        private void Addbt_Click(object sender, EventArgs e)
        {
            Excel.Range stringname = (Excel.Range)exSheet.Cells[key+1, 1];
            Excel.Range stringphone = (Excel.Range)exSheet.Cells[key+1, 2];
            Excel.Range stringroom = (Excel.Range)exSheet.Cells[key+1, 3];
            
            try
            {
                name = nametxt.Text;
                phone = phonetxt.Text;
                if (nametxt.Text == "" || phonetxt.Text == "" || roomtxt.Text == "" || (roomtxt.Text != "1" && roomtxt.Text != "2" && roomtxt.Text != "3"))
                    throw new System.Exception();
                else
                if (roomtxt.Text == "1")
                    Q1.enqueue(name, phone, key);
                else
                if (roomtxt.Text == "2")
                    Q2.enqueue(name, phone, key);
                else
                if (roomtxt.Text == "3")
                    Q3.enqueue(name, phone, key);
                stringname.Value2 = name;
                stringphone.Value2 = phone;
                stringroom.Value2 = roomtxt.Text;
                key++;
                nolbl.Text = key.ToString();
                MessageBox.Show("Đã thêm bệnh nhân vào hàng chờ Phòng khám " + roomtxt.Text , "Added", MessageBoxButtons.OK,MessageBoxIcon.Information);
                nametxt.Text = "";
                phonetxt.Text = "";
                roomtxt.Text = "";
                
            }
            catch(Exception)
            {
                MessageBox.Show("Khong hop le", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
          
        }

        private void Nextbt1_Click(object sender, EventArgs e)
        {
            QNode t;
            t = Q1.dequeue();
            if (t != null)
            {
                namelbl.Text = t.name;
                numberlbl.Text = t.key.ToString();
                roomlbl.Text = "1";
                phonelbl.Text = t.phone;
            }
            else
                MessageBox.Show("Không còn bệnh nhân nào", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Nextbt2_Click(object sender, EventArgs e)
        {
            QNode t;
            t = Q2.dequeue();
            if (t != null)
            {
                namelbl.Text = t.name;
                numberlbl.Text = t.key.ToString();
                roomlbl.Text = "2";
                phonelbl.Text = t.phone;
            }
            else
                MessageBox.Show("Không còn bệnh nhân nào", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Nextbt3_Click(object sender, EventArgs e)
        {
            QNode t;
            t = Q3.dequeue();
            if (t != null)
            {
                namelbl.Text = t.name;
                numberlbl.Text = t.key.ToString();
                roomlbl.Text = "3";
                phonelbl.Text = t.phone;
            }
            else
                MessageBox.Show("Không còn bệnh nhân nào", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Exitbt_Click(object sender, EventArgs e)
        {
            if(Q1.IsEmpty()==true && Q2.IsEmpty() == true && Q3.IsEmpty() == true)
            {
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn dừng chương trình", "Exit?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if(result == DialogResult.Yes)
                {
                    DialogResult result1 = MessageBox.Show("Bạn có muốn lưu dữ liệu vào file?", "Save?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if(result1 == DialogResult.Yes)
                    {
                        exBook.SaveAs("E:\\" + dateimenow, Excel.XlFileFormat.xlWorkbookNormal, null, null, false, false, Excel.XlSaveAsAccessMode.xlNoChange, false, false, false, false, false);
                        exBook.Save();
                        exBook.Close(true, false, false);
                    }
                    else
                        exBook.Close(false, false, false);
                    exApp.Quit();
                    System.Runtime.InteropServices.Marshal.FinalReleaseComObject(exBook);
                    System.Runtime.InteropServices.Marshal.FinalReleaseComObject(exApp);
                    Close();
                }
            }
            else
            {
                DialogResult result2 = MessageBox.Show("Vẫn còn bệnh nhân đang chờ, Bạn chắc chắn muốn dừng chương trình?", "Exit?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if(result2 == DialogResult.Yes)
                {
                    DialogResult result3 = MessageBox.Show("Bạn có muốn lưu dữ liệu vào file?", "Save?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result3 == DialogResult.Yes)
                    {
                        exBook.SaveAs("E:\\" + dateimenow, Excel.XlFileFormat.xlWorkbookNormal, null, null, false, false, Excel.XlSaveAsAccessMode.xlNoChange, false, false, false, false, false);
                        exBook.Save();
                        exBook.Close(true, false, false);
                    }
                    else
                        exBook.Close(false, false, false);
                    exApp.Quit();
                    System.Runtime.InteropServices.Marshal.FinalReleaseComObject(exBook);
                    System.Runtime.InteropServices.Marshal.FinalReleaseComObject(exApp);
                    Close();
                }
            }
        }
    }

}
